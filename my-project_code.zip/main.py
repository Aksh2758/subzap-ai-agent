import streamlit as st
import pandas as pd
from google.cloud.alloydb.connector import Connector
import sqlalchemy
import vertexai
from vertexai.generative_models import GenerativeModel
import os

# --- 1. CONFIGURATION ---
PROJECT_ID = "buoyant-lattice-434918-f7" 
DB_REGION = "asia-south1"            
CLUSTER_ID = "hackathon-cluster"
INSTANCE_ID = "hackathon-cluster-primary"
DB_NAME = "postgres"
DB_USER = "postgres"
DB_PASS = "Hackathon123"             
AI_REGION = "us-central1"            

INSTANCE_URI = f"projects/{PROJECT_ID}/locations/{DB_REGION}/clusters/{CLUSTER_ID}/instances/{INSTANCE_ID}"

# --- 2. DATABASE CONNECTION ---
@st.cache_resource
def get_connection_pool():
    connector = Connector()
    def getconn():
        conn = connector.connect(
            INSTANCE_URI,
            "pg8000",
            user=DB_USER,
            password=DB_PASS,
            db=DB_NAME,
            ip_type="PRIVATE"
        )
        return conn
    pool = sqlalchemy.create_engine("postgresql+pg8000://", creator=getconn)
    return pool

# --- 3. DATA LOADER ---
def reset_and_load_data():
    try:
        pool = get_connection_pool()
        with pool.connect() as db_conn:
            db_conn.execute(sqlalchemy.text("DROP TABLE IF EXISTS transactions;"))
            db_conn.commit()
            df = pd.read_csv("transactions.csv")
            df.columns = [c.lower() for c in df.columns] 
            df['date'] = pd.to_datetime(df['date'])
            df.to_sql('transactions', db_conn, if_exists='replace', index=False)
            st.sidebar.success(f"✅ Reset Complete: {len(df)} rows.")
    except Exception as e:
        st.sidebar.error(f"❌ Error: {str(e)}")

# --- 4. AI ENGINE ---
def ask_gemini_to_write_sql(user_question):
    vertexai.init(project=PROJECT_ID, location=AI_REGION)
    model = GenerativeModel("gemini-2.0-flash-exp") 
    prompt = f"""
    You are a PostgreSQL expert. Convert the user's request into a SQL query.
    Table: 'transactions'
    Columns: id, date (timestamp), description (text), amount (float), category (text)
    
    Rules: 
    1. Return ONLY the raw SQL code. No markdown.
    2. Case insensitive searches: Use ILIKE.
    3. For 'subscriptions', look for repeating descriptions or keywords: 'Spotify', 'Netflix', 'Adobe', 'Gym', 'Chegg', 'Hulu'.
    
    User Question: {user_question}
    """
    response = model.generate_content(prompt)
    return response.text.replace("```sql", "").replace("```", "").strip()

def ask_gemini_to_explain(user_question, data_summary):
    vertexai.init(project=PROJECT_ID, location=AI_REGION)
    model = GenerativeModel("gemini-2.0-flash-exp")
    prompt = f"""
    User Question: {user_question}
    Data Found: 
    {data_summary}

    Act as a financial advisor "SubZap". 
    Analyze the data. Be concise and professional.
    Highlight specific wasted money if found.
    """
    response = model.generate_content(prompt)
    return response.text

# --- 5. FRONTEND ---
st.set_page_config(page_title="SubZap AI", page_icon="💸", layout="wide")

# Custom CSS for a professional look
st.markdown("""
<style>
    .stButton>button {
        width: 100%;
        border-radius: 8px;
        height: 3em;
    }
    /* Remove background from metrics to fix the visual glitch */
    [data-testid="stMetricValue"] {
        font-size: 24px;
    }
</style>
""", unsafe_allow_html=True)

st.title("💸 SubZap: Subscription Zombie Hunter")
st.caption("Powered by **AlloyDB** & **Gemini 2.0 Flash**")

# --- SIDEBAR DASHBOARD ---
with st.sidebar:
    st.image("https://cdn-icons-png.flaticon.com/512/2953/2953363.png", width=80)
    st.title("Your Finances")
    
    # Live Metrics (Queries DB directly for realism)
    try:
        pool = get_connection_pool()
        with pool.connect() as db_conn:
            res = db_conn.execute(sqlalchemy.text("SELECT COUNT(*), SUM(amount) FROM transactions")).fetchone()
            count = res[0]
            total_spend = f"${res[1]:,.2f}" if res[1] else "$0"
    except:
        count = 0
        total_spend = "$0"

    col1, col2 = st.columns(2)
    col1.metric("Transactions", count)
    col2.metric("Total Spend", total_spend)
    
    st.divider()
    st.subheader("⚡ Quick Actions")
    
    # Quick Buttons to insert prompt
    if st.button("🔍 Find Zombie Subscriptions"):
        st.session_state.prompt_input = "Identify my recurring subscriptions and calculate the monthly cost."
    if st.button("🍔 Food Spending Analysis"):
        st.session_state.prompt_input = "How much did I spend on Food and Groceries last month?"
    if st.button("📉 What should I cancel?"):
        st.session_state.prompt_input = "Which subscriptions are the most expensive? Recommend what to cancel."
        
    st.divider()
    with st.expander("Admin Panel"):
        if st.button("🔄 HARD RESET DATABASE"):
            reset_and_load_data()

# --- CHAT INTERFACE ---
if "messages" not in st.session_state:
    st.session_state.messages = []
    # Initial Greeting
    st.session_state.messages.append({"role": "assistant", "content": "Hello! I am SubZap. I have analyzed your 2,000+ bank transactions. Ask me anything!"})

# Handle Button Clicks
if "prompt_input" in st.session_state and st.session_state.prompt_input:
    user_input = st.session_state.prompt_input
    del st.session_state.prompt_input # Clear after use
else:
    user_input = None

# Display History
for message in st.session_state.messages:
    avatar = "🤖" if message["role"] == "assistant" else "👤"
    with st.chat_message(message["role"], avatar=avatar):
        st.markdown(message["content"])

# Chat Input (Bottom)
if prompt := st.chat_input("Ask about your subscriptions...") or user_input:
    # If it came from a button, use that text
    final_prompt = user_input if user_input else prompt

    st.session_state.messages.append({"role": "user", "content": final_prompt})
    with st.chat_message("user", avatar="👤"):
        st.markdown(final_prompt)

    with st.chat_message("assistant", avatar="🤖"):
        message_placeholder = st.empty()
        message_placeholder.markdown("🧠 **Analyzing AlloyDB data...**")
        try:
            # 1. Generate SQL
            sql = ask_gemini_to_write_sql(final_prompt)
            
            # 2. Run SQL
            pool = get_connection_pool()
            with pool.connect() as db_conn:
                result_df = pd.read_sql(sql, db_conn)
            
            # 3. Explain
            if result_df.empty:
                final_answer = "I ran the query but found no matching records."
                st.code(sql, language='sql')
            else:
                data_str = result_df.head(20).to_string(index=False)
                final_answer = ask_gemini_to_explain(final_prompt, data_str)
                
                # Show SQL only inside an expander (Cleaner look)
                with st.expander("View Technical Details (SQL & Data)"):
                    st.code(sql, language='sql')
                    st.dataframe(result_df)

            message_placeholder.markdown(final_answer)
            st.session_state.messages.append({"role": "assistant", "content": final_answer})

        except Exception as e:
            st.error(f"Error: {str(e)}")